﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAS
{
    class Business
    {
        private int _gewonnen=0;
        public int Gewonnen
        {
            get { return _gewonnen; }
            set { _gewonnen = value; }
        }

        private int _verloren=0;
        public int Verloren
        {
            get { return _verloren; }
            set { _verloren = value; }
        }

        private int _pc;
        public int Pc
        {
            get { Berekening(); return _pc; }
            set { _pc = value;Berekening(); }
        }

        private int _score;
        public int Score
        {
            get { Berekening(); return _score; }
            set { _score = value;Berekening(); }
        }

        private void Berekening()
        {
            Random rnd = new Random();
            _pc = rnd.Next(1, 4);

            if (_gewonnen == 0)
            {
                _score = 50;
            }
            else
            {
                if(_gewonnen >0 && _gewonnen < 4)
                {
                    _score = 200;
                }
                else
                {
                    if(_gewonnen>3 && _gewonnen<7)
                    {
                        _score = 400;
                    }
                    else
                    {
                        if (_gewonnen > 6 && _gewonnen < 10)
                        {
                            _score = 600;
                        }
                        else
                        {
                            _score = 900;
                        }
                    }
                }
            }
        }
    }
}
