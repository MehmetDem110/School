﻿namespace DAS
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.lblVerloren = new System.Windows.Forms.Label();
            this.lblGewonnen = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblTitel = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pctkleurSteen = new System.Windows.Forms.PictureBox();
            this.pctkleurSchaar = new System.Windows.Forms.PictureBox();
            this.pctkleurBlad = new System.Windows.Forms.PictureBox();
            this.pctSchaar = new System.Windows.Forms.PictureBox();
            this.pctSteen = new System.Windows.Forms.PictureBox();
            this.pctBlad = new System.Windows.Forms.PictureBox();
            this.btnUitleg = new System.Windows.Forms.Button();
            this.btnPlay = new System.Windows.Forms.Button();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.btnOpnieuw = new System.Windows.Forms.Button();
            this.lblScore = new System.Windows.Forms.Label();
            this.btnPunten = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctkleurSteen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctkleurSchaar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctkleurBlad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctSchaar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctSteen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctBlad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(296, 440);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(192, 22);
            this.label1.TabIndex = 2;
            this.label1.Text = "aantal keer gewonnen:";
            // 
            // lblVerloren
            // 
            this.lblVerloren.AutoSize = true;
            this.lblVerloren.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVerloren.Location = new System.Drawing.Point(504, 476);
            this.lblVerloren.Name = "lblVerloren";
            this.lblVerloren.Size = new System.Drawing.Size(0, 22);
            this.lblVerloren.TabIndex = 5;
            // 
            // lblGewonnen
            // 
            this.lblGewonnen.AutoSize = true;
            this.lblGewonnen.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGewonnen.Location = new System.Drawing.Point(504, 440);
            this.lblGewonnen.Name = "lblGewonnen";
            this.lblGewonnen.Size = new System.Drawing.Size(0, 22);
            this.lblGewonnen.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(292, 476);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(179, 22);
            this.label4.TabIndex = 7;
            this.label4.Text = "aantal keer verloren: ";
            // 
            // lblTitel
            // 
            this.lblTitel.AutoSize = true;
            this.lblTitel.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(137)))), ((int)(((byte)(33)))));
            this.lblTitel.Location = new System.Drawing.Point(315, 75);
            this.lblTitel.Name = "lblTitel";
            this.lblTitel.Size = new System.Drawing.Size(0, 69);
            this.lblTitel.TabIndex = 8;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(915, 12);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(10, 532);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 18;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(12, 12);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(10, 532);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 17;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(12, 534);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(913, 10);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 16;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(12, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(913, 10);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 15;
            this.pictureBox2.TabStop = false;
            // 
            // pctkleurSteen
            // 
            this.pctkleurSteen.Location = new System.Drawing.Point(360, 186);
            this.pctkleurSteen.Name = "pctkleurSteen";
            this.pctkleurSteen.Size = new System.Drawing.Size(186, 10);
            this.pctkleurSteen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctkleurSteen.TabIndex = 13;
            this.pctkleurSteen.TabStop = false;
            this.pctkleurSteen.Visible = false;
            // 
            // pctkleurSchaar
            // 
            this.pctkleurSchaar.Location = new System.Drawing.Point(552, 186);
            this.pctkleurSchaar.Name = "pctkleurSchaar";
            this.pctkleurSchaar.Size = new System.Drawing.Size(186, 10);
            this.pctkleurSchaar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctkleurSchaar.TabIndex = 12;
            this.pctkleurSchaar.TabStop = false;
            this.pctkleurSchaar.Visible = false;
            // 
            // pctkleurBlad
            // 
            this.pctkleurBlad.Location = new System.Drawing.Point(168, 186);
            this.pctkleurBlad.Name = "pctkleurBlad";
            this.pctkleurBlad.Size = new System.Drawing.Size(186, 10);
            this.pctkleurBlad.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctkleurBlad.TabIndex = 11;
            this.pctkleurBlad.TabStop = false;
            this.pctkleurBlad.Visible = false;
            // 
            // pctSchaar
            // 
            this.pctSchaar.BackColor = System.Drawing.SystemColors.Control;
            this.pctSchaar.Image = global::DAS.Properties.Resources.schaar;
            this.pctSchaar.Location = new System.Drawing.Point(552, 202);
            this.pctSchaar.Name = "pctSchaar";
            this.pctSchaar.Size = new System.Drawing.Size(186, 175);
            this.pctSchaar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctSchaar.TabIndex = 10;
            this.pctSchaar.TabStop = false;
            this.pctSchaar.Click += new System.EventHandler(this.pctSchaar_Click);
            // 
            // pctSteen
            // 
            this.pctSteen.BackColor = System.Drawing.SystemColors.Control;
            this.pctSteen.Image = global::DAS.Properties.Resources.steen;
            this.pctSteen.Location = new System.Drawing.Point(360, 202);
            this.pctSteen.Name = "pctSteen";
            this.pctSteen.Size = new System.Drawing.Size(186, 175);
            this.pctSteen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctSteen.TabIndex = 9;
            this.pctSteen.TabStop = false;
            this.pctSteen.Click += new System.EventHandler(this.pctSteen_Click);
            // 
            // pctBlad
            // 
            this.pctBlad.BackColor = System.Drawing.SystemColors.Control;
            this.pctBlad.Image = global::DAS.Properties.Resources.papier;
            this.pctBlad.Location = new System.Drawing.Point(168, 202);
            this.pctBlad.Name = "pctBlad";
            this.pctBlad.Size = new System.Drawing.Size(186, 175);
            this.pctBlad.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctBlad.TabIndex = 0;
            this.pctBlad.TabStop = false;
            this.pctBlad.Click += new System.EventHandler(this.pctBlad_Click);
            // 
            // btnUitleg
            // 
            this.btnUitleg.Location = new System.Drawing.Point(767, 490);
            this.btnUitleg.Name = "btnUitleg";
            this.btnUitleg.Size = new System.Drawing.Size(142, 38);
            this.btnUitleg.TabIndex = 19;
            this.btnUitleg.Text = "hoe werkt het?";
            this.btnUitleg.UseVisualStyleBackColor = true;
            this.btnUitleg.Click += new System.EventHandler(this.btnUitleg_Click);
            // 
            // btnPlay
            // 
            this.btnPlay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnPlay.Font = new System.Drawing.Font("Arial Rounded MT Bold", 120F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlay.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnPlay.Location = new System.Drawing.Point(-23, -14);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(980, 669);
            this.btnPlay.TabIndex = 20;
            this.btnPlay.Text = "play";
            this.btnPlay.UseVisualStyleBackColor = false;
            this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Location = new System.Drawing.Point(217, 214);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(521, 15);
            this.pictureBox6.TabIndex = 22;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Location = new System.Drawing.Point(217, 439);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(521, 15);
            this.pictureBox7.TabIndex = 23;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Location = new System.Drawing.Point(217, 215);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(14, 234);
            this.pictureBox8.TabIndex = 24;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Location = new System.Drawing.Point(720, 214);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(18, 240);
            this.pictureBox9.TabIndex = 25;
            this.pictureBox9.TabStop = false;
            // 
            // btnOpnieuw
            // 
            this.btnOpnieuw.Location = new System.Drawing.Point(767, 351);
            this.btnOpnieuw.Name = "btnOpnieuw";
            this.btnOpnieuw.Size = new System.Drawing.Size(142, 40);
            this.btnOpnieuw.TabIndex = 26;
            this.btnOpnieuw.Text = "opnieuw";
            this.btnOpnieuw.UseVisualStyleBackColor = true;
            this.btnOpnieuw.Visible = false;
            this.btnOpnieuw.Click += new System.EventHandler(this.btnOpnieuw_Click);
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScore.Location = new System.Drawing.Point(405, 509);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(0, 22);
            this.lblScore.TabIndex = 28;
            // 
            // btnPunten
            // 
            this.btnPunten.Location = new System.Drawing.Point(767, 422);
            this.btnPunten.Name = "btnPunten";
            this.btnPunten.Size = new System.Drawing.Size(142, 40);
            this.btnPunten.TabIndex = 29;
            this.btnPunten.Text = "Punten";
            this.btnPunten.UseVisualStyleBackColor = true;
            this.btnPunten.Visible = false;
            this.btnPunten.Click += new System.EventHandler(this.btnPunten_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(123)))), ((int)(((byte)(167)))));
            this.ClientSize = new System.Drawing.Size(937, 556);
            this.Controls.Add(this.btnPunten);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.btnOpnieuw);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.btnPlay);
            this.Controls.Add(this.btnUitleg);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pctkleurSteen);
            this.Controls.Add(this.pctkleurSchaar);
            this.Controls.Add(this.pctkleurBlad);
            this.Controls.Add(this.pctSchaar);
            this.Controls.Add(this.pctSteen);
            this.Controls.Add(this.lblTitel);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblGewonnen);
            this.Controls.Add(this.lblVerloren);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pctBlad);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Blad Steen Schaar!";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctkleurSteen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctkleurSchaar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctkleurBlad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctSchaar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctSteen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctBlad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pctBlad;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblVerloren;
        private System.Windows.Forms.Label lblGewonnen;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblTitel;
        private System.Windows.Forms.PictureBox pctSteen;
        private System.Windows.Forms.PictureBox pctSchaar;
        private System.Windows.Forms.PictureBox pctkleurBlad;
        private System.Windows.Forms.PictureBox pctkleurSchaar;
        private System.Windows.Forms.PictureBox pctkleurSteen;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Button btnUitleg;
        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Button btnOpnieuw;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Button btnPunten;
    }
}

