﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAS
{
    public partial class Form1 : Form
    {
        Business _business = new Business();
        public Form1()
        {
            InitializeComponent();
        }

        private void pctBlad_Click(object sender, EventArgs e)
        {
            pctkleurBlad.Visible = true;
            pctkleurSteen.Visible = false;
            pctkleurSchaar.Visible = false;
            pctkleurBlad.BackColor = Color.Green;
            if (_business.Pc == 1)  //blad
            {
                pctkleurBlad.Visible = true;
                pctkleurBlad.BackColor=Color.Orange;
                lblTitel.Text = "Gelijk";
                lblTitel.ForeColor = Color.Orange;
            }
            else
            {
                if (_business.Pc == 2)   //steen
                {
                    pctkleurSteen.Visible = true;
                    pctkleurSteen.BackColor=Color.Red;
                    _business.Gewonnen++;
                    lblTitel.Text = "Gewonnen";
                    lblTitel.ForeColor = Color.LimeGreen;
                }
                else
                {
                    if (_business.Pc == 3)  //schaar
                    {
                        pctkleurSchaar.Visible = true;
                        pctkleurSchaar.BackColor=Color.Red;
                        _business.Verloren++;
                        lblTitel.Text = "Verloren";
                        lblTitel.ForeColor = Color.Red;
                    }
                }
            }
            lblVerloren.Text = _business.Verloren.ToString();
            lblGewonnen.Text = _business.Gewonnen.ToString();
            if (_business.Verloren >= 5)
            {
                MessageBox.Show("Je " + _business.Score + " punten gewonnen!!!", "Score!");
                _business.Gewonnen = 0;
                _business.Verloren = 0;

            }
        }

        private void pctSteen_Click(object sender, EventArgs e)
        {
            pctkleurBlad.Visible = true;
            pctkleurSteen.Visible = false;
            pctkleurSchaar.Visible = false;
            pctkleurBlad.BackColor = Color.Green;
            if (_business.Pc == 1)  //blad
            {
                pctkleurBlad.Visible = true;
                pctkleurBlad.BackColor = Color.Orange;
                lblTitel.Text = "Gelijk";
                lblTitel.ForeColor = Color.Orange;
            }
            else
            {
                if (_business.Pc == 2)   //steen
                {
                    pctkleurSteen.Visible = true;
                    pctkleurSteen.BackColor = Color.Red;
                    _business.Gewonnen++;
                    lblTitel.Text = "Gewonnen";
                    lblTitel.ForeColor = Color.LimeGreen;
                }
                else
                {
                    if (_business.Pc == 3)  //schaar
                    {
                        pctkleurSchaar.Visible = true;
                        pctkleurSchaar.BackColor = Color.Red;
                        _business.Verloren++;
                        lblTitel.Text = "Verloren";
                        lblTitel.ForeColor = Color.Red;
                    }
                }
            }
            lblVerloren.Text = _business.Verloren.ToString();
            lblGewonnen.Text = _business.Gewonnen.ToString();
            if (_business.Verloren >= 5)
            {
                MessageBox.Show("Je " + _business.Score + " punten gewonnen!!!", "Score!");
                _business.Gewonnen = 0;
                _business.Verloren = 0;

            }
        }

        private void pctSchaar_Click(object sender, EventArgs e)
        {
            pctkleurBlad.Visible = true;
            pctkleurSteen.Visible = false;
            pctkleurSchaar.Visible = false;
            pctkleurBlad.BackColor = Color.Green;
            if (_business.Pc == 1)  //blad
            {
                pctkleurBlad.Visible = true;
                pctkleurBlad.BackColor = Color.Orange;
                lblTitel.Text = "Gelijk";
                lblTitel.ForeColor = Color.Orange;
            }
            else
            {
                if (_business.Pc == 2)   //steen
                {
                    pctkleurSteen.Visible = true;
                    pctkleurSteen.BackColor = Color.Red;
                    _business.Gewonnen++;
                    lblTitel.Text = "Gewonnen";
                    lblTitel.ForeColor = Color.LimeGreen;
                }
                else
                {
                    if (_business.Pc == 3)  //schaar
                    {
                        pctkleurSchaar.Visible = true;
                        pctkleurSchaar.BackColor = Color.Red;
                        _business.Verloren++;
                        lblTitel.Text = "Verloren";
                        lblTitel.ForeColor = Color.Red;
                    }
                }
            }
            lblVerloren.Text = _business.Verloren.ToString();
            lblGewonnen.Text = _business.Gewonnen.ToString();

            if (_business.Verloren >= 5)
            {
                MessageBox.Show("Je " + _business.Score + " punten gewonnen!!!", "Score!");
                _business.Gewonnen = 0;
                _business.Verloren = 0;
            }
        }

        private void btnUitleg_Click(object sender, EventArgs e)
        {
            MessageBox.Show("welkom bij blad, steen , schaar. hoe meer wins je hebt = hoe meer punten je verdiend. u tegenstander is een pc. \n \n " +
                "veel succes","Hoe werkt het?");
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            btnPlay.Visible = false;
            btnPunten.Visible = true;
            pictureBox6.Visible = false;
            pictureBox7.Visible = false;
            pictureBox8.Visible = false;
            pictureBox9.Visible = false;
            pictureBox9.Visible = false;
            pictureBox9.Visible = false;
            btnOpnieuw.Visible = true;
        }

        private void btnOpnieuw_Click(object sender, EventArgs e)
        {
            _business.Gewonnen = 0;
            _business.Verloren = 0;
            lblGewonnen.Text = _business.Gewonnen.ToString();
            lblVerloren.Text = _business.Verloren.ToString();
        }

        private void btnPunten_Click(object sender, EventArgs e)
        {
            MessageBox.Show("de punten zijn als volgt:\n" +
                "0 wins = 50 punten\n" +
                "1 tot en met 3 wins = 200 punten\n" +
                "4 tot en met 6 wins = 400 punten\n" +
                "7 tot en met 9 wins = 600 punten\n" +
                "meer dan 9 wins = 900punten", "Punten");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
